function playMusic() {
    const audio = document.getElementById('music');
    const message = document.getElementById('playMessage');
    
    // Putar musik
    audio.play();
    
    // Tampilkan pesan tambahan
    message.style.display = 'block';
    
    // Opsional: Sembunyikan pesan setelah musik selesai (jika diinginkan)
    audio.onended = function() {
        message.style.display = 'none';
    };
}